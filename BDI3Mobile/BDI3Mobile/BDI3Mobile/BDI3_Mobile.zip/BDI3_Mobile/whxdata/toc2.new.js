(function() {
var toc =  [{"type":"item","name":"About Child Information","url":"Child_Administration/About_Reports.htm#bc-1"},{"type":"item","name":"Add a child record","url":"Child_Administration/Add_child.htm"},{"type":"item","name":"Search for a child record","url":"Child_Administration/FInd_a_child_record.htm"},{"type":"item","name":"Edit a child record","url":"Child_Administration/Edit_child.htm"},{"type":"item","name":"Child Information page","url":"Child_Administration/Child_Information_page.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();