(function() {
var toc =  [{"type":"item","name":"Welcome to BDI-3 online help","url":"Welcome_to_BDI_3_Online_Help.htm"},{"type":"item","name":"Download BDI3 MDS","url":"Download_BDI3_MDS.htm"},{"type":"book","name":"Getting Started","key":"toc1","url":"Basics/Riverside_Score_for_BDI-3_Overview.htm"},{"type":"book","name":"Child Administration","key":"toc2","url":"Child_Administration/About_Reports.htm"},{"type":"book","name":"Assessments","key":"toc3"},{"type":"book","name":"Reports","key":"toc4"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();