(function() {
var toc =  [{"type":"item","name":"About Reports","url":"Reports/Reports_Overview.htm"},{"type":"item","name":"Basic report","url":"Reports/Create_reports.htm"},{"type":"item","name":"Full report","url":"Reports/Family_Report.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();